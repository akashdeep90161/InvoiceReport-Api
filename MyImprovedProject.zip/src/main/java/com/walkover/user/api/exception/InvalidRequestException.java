package com.walkover.user.api.exception;

/**
 * @author Akash Deep Gupta
 */
public class InvalidRequestException extends Exception {

    public InvalidRequestException(String message) {
        super(message);
    }
}
