package com.walkover.user.api.exception;

/**
 * @author Akash Deep Gupta
 */
public class InvalidParameterException extends Exception {

    public InvalidParameterException(String message) {
        super(message);
    }
}
