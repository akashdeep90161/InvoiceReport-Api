package com.walkover.user.api.exception;

/**
 * @author Akash Deep Gupta
 */
public class UnAuthorizeException extends Exception {

    public UnAuthorizeException(String message) {
        super(message);
    }

}
