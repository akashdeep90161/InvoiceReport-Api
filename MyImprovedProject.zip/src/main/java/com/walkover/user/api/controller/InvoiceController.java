package com.walkover.user.api.controller;


import com.fasterxml.jackson.annotation.JsonView;
import com.walkover.user.api.dao.model.Invoice;
import com.walkover.user.api.dao.model.Item;
import com.walkover.user.api.dao.model.User;
import com.walkover.user.api.dao.repository.ItemRepository;
import com.walkover.user.api.dao.repository.UserRepository;
import com.walkover.user.api.models.commens.ApiResponse;
import com.walkover.user.api.models.commens.ApiStatus;
import com.walkover.user.api.resources.v1.ItemResource;
import com.walkover.user.api.services.v1.InvoiceService;
import com.walkover.user.api.services.v1.ItemService;
import com.walkover.user.api.services.v1.UserService;
import com.walkover.user.api.utils.commons.JsonViews;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.HttpServletRequest;

import java.util.List;

import static org.springframework.web.bind.annotation.RequestMethod.GET;

@Controller
@RequestMapping("/invoice")
public class InvoiceController {

   private final InvoiceService invoiceService;

  public InvoiceController(InvoiceService invoiceService) {
      this.invoiceService = invoiceService;
   }
 // @JsonView(JsonViews.userDetailsExcludingPassword.class)
   @RequestMapping(method = GET, value = "/{id}")
   public ResponseEntity<ApiResponse> getInvoice(@PathVariable long id, HttpServletRequest request) throws Exception {
     /* List<Item> items = itemService.getItemByUserId(id);
      String totalAmount =itemService.getTotalAmount(id);
      Invoice invoice=new Invoice();
      invoice.setTotalAmount(totalAmount);
      invoice.setUserId(id);
      invoice.setItems(items);
      invoice.setInvoiceId(101);*/
      Invoice invoice = invoiceService.createInvoice(id);
       //System.out.println("First Item "+invoice.getItems().get(0).getItemName());
      return new ResponseEntity<>(new ApiResponse(invoice, ApiStatus.success), HttpStatus.OK);
   }

}
