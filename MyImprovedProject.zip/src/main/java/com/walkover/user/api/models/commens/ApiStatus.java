package com.walkover.user.api.models.commens;

import lombok.AllArgsConstructor;
import lombok.Getter;


/**
 * @author Akash Deep Gupta
 **/


@Getter
@AllArgsConstructor
public enum ApiStatus {
    success, error;
}
