package com.walkover.user.api.exception;

/**
 * @author Akash Deep Gupta
 */
public class AlreadyExistException extends Exception {

    public AlreadyExistException(String message) {
        super(message);
    }
}
