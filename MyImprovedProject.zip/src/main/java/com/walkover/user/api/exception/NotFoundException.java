package com.walkover.user.api.exception;

/**
 * @author Akash Deep Gupta
 */
public class NotFoundException extends Exception {

    public NotFoundException(String message) {
        super(message);
    }

}
