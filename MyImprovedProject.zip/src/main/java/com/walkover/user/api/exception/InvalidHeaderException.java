package com.walkover.user.api.exception;

/**
 * @author Akash Deep Gupta
 */
public class InvalidHeaderException extends Exception {

    public InvalidHeaderException(String message) {
        super(message);
    }
}
